/*4. Dado uma sequ�ncia de n n�meros inteiros quaisquer que representam as
temperaturas m�dias di�rias num dado per�odo, determinar a m�dia aritm�tica da
temperatura no mesmo per�odo.*/
#include <stdio.h>

int main()
{
    int num;
    int soma = 0;

    printf("Ola digite o numero de temperaturas: ");
    scanf("%d", &num);

    if (num <= 0)
    {
        printf("Por favor, insira um n�mero positivo.\n");
    }
        else
        {
            int temperatura;
            for (int i = 1; i <= num; i++)
            {
                printf("Digite a temperatura %d: ", i);
                scanf("%d", &temperatura);
                soma += temperatura;
            }

        float media = (float)soma / num;

        printf("A media das temperaturas eh: %.2f\n", media);
        }

    return 0;
}
