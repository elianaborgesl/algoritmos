/*5. Considere x inteiro e n natural, calcular a pot�ncia x por n.*/
#include <stdio.h>

int main()
{
    int x, num, resultado = 1;

    printf("ola digite um numero para base: ");
    scanf("%d", &x);

    printf("Digite um valor para expoente: ");
    scanf("%d", &num);

    for (int i = 0; i < num; i++)
    {
        resultado *= x;
    }

    printf("%d elevado a %d eh igual a %d\n", x, num, resultado);

    return 0;
}

