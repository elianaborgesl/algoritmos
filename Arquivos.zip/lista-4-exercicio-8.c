/*8. Dado um inteiro positivo n, determinar o fatorial de n, que denotamos por n!. */
#include <stdio.h>

int main() {
    int n, fatorial = 1;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &n);

    if (n < 0)
    {
        printf("Por favor, insira um numero inteiro positivo.\n");
    }
        else
        {
        for (int i = 1; i <= n; i++) {
            fatorial *= i;
        }

        printf("%d! = %d\n", n, fatorial);
    }

    return 0;
}

