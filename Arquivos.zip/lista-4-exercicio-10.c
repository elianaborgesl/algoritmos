/*10. Considere um inteiro p > 1, verificar se p � primo.*/
#include <stdio.h>

int main()
{
    int p, ehPrimo = 1; // o nosso p � o primo
    printf("Digite um inteiro positivo maior que 1: ");
    scanf("%d", &p);

    if (p <= 1)
    {
        printf("Por favor, insira um inteiro positivo maior que 1.\n");
    }
        else
        {
            for (int i = 2; i < p; i++)
            {
            if (p % i == 0)
            {
                ehPrimo = 0; // p n�o � primo
                break; // Saia do loop, n�o � necess�rio verificar mais
            }
        }

        if (ehPrimo)
        {
            printf("%d eh primo.\n", p);
        } else {
            printf("%d nao eh primo.\n", p);
        }
        }

    return 0;
}
