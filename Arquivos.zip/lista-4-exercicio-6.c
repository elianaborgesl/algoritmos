/*6. Dado uma sequ�ncia de n n�meros inteiros quaisquer. Encontre o maior e o menor
valor dessa sequ�ncia.*/
#include <stdio.h>

int main()
{
    int n, numero, maior, menor;

    printf("ola, por favor igite a quantidade de numeros na sequencia: ");
    scanf("%d", &n);

    if (n <= 0)
    {
        printf("Agora insira um numero positivo para a quantidade de numeros.\n");
        return 1; // Saia do programa com c�digo de erro
    }

        printf("Digite o primeiro numero: ");
        scanf("%d", &numero);

        maior = numero;
        menor = numero;

            for (int i = 1; i < n; i++)
            {
                printf("Por fim digite o proximo numero: ");
                scanf("%d", &numero);

            if (numero > maior)
            {
            maior = numero;
            }

                if (numero < menor)
                {
                menor = numero;
                }
            }

    printf("O maior valor na sequencia eh: %d\n", maior);
    printf("O menor valor na sequencia eh: %d\n", menor);

    return 0;
}
