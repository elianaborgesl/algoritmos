/*11. Diz-se que dois n�meros primos s�o g�meos, se eles s�o �mpares consecutivos.
Exemplo: 3 e 5, 5 e 7, 11, e 13. Encontre todos os primos g�meos no intervalo
[3,1000].*/
#include <stdio.h>

int main()
{
    printf("ola esses ao os numeros primos gemeos no intervalo [3, 1000]:\n");

    for (int numero = 3; numero <= 998; numero += 2)
        {
        int ehPrimo = 1;
        if (numero <= 1)
            {
            ehPrimo = 0;
            } else {
            for (int i = 2; i * i <= numero; i++)
            {
                if (numero % i == 0)
                {
                    ehPrimo = 0;
                    break;
                }
            }
        }

        int ehProximoPrimo = 1;

        if (numero + 2 <= 1000)
        {
            for (int i = 2; i * i <= numero + 2; i++)
            {
                if ((numero + 2) % i == 0)
                {
                    ehProximoPrimo = 0;
                    break;
                }
            }
        }
        else
        {
            ehProximoPrimo = 0;
        }

        if (ehPrimo && ehProximoPrimo)
        {
            printf("(%d, %d)\n", numero, numero + 2);
        }
    }

    return 0;
}

