#include<stdio.h>
int main()
{
    int n,i,j,x=1, cont=0;


    scanf("%d", &n);
    scanf("%d", &i);
    scanf("%d", &j);

    while(x<=n)
    {
        if(x%i==0 || x%j==0)
        {
             printf("%d", x);
            cont ++;
        }
            x++;
    }




    return 0;
}
