/*1. Dada uma sequ�ncia de n�meros naturais em que o �ltimo elemento � 0 (zero),
imprimir seus quadrados.*/
#include <stdio.h>

int main()
{
    int numero;

    printf("Por favor escreva uma sequencia de numeros naturais que termine com 0:\n");

    do {
        scanf("%d", &numero);
        if (numero != 0)
        {
            int quadrado = numero * numero;
            printf("O quadrado de %d eh %d\n", numero, quadrado);
        }
    } while (numero != 0);

    return 0;
}
