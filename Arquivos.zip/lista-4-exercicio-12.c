/*12. Encontre todos os n�meros primos entre 2 e 20.000.*/
#include <stdio.h>

int main()
{
    const int limite = 20000;
    int numerosPrimos[limite + 1];

    for (int i = 2; i <= limite; i++)
    {
        numerosPrimos[i] = 1;
    }

    for (int p = 2; p * p <= limite; p++)
    {
        if (numerosPrimos[p] == 1)
        {
            for (int i = p * p; i <= limite; i += p)
            {
                numerosPrimos[i] = 0;
            }
        }
    }

    printf("N�meros primos entre 2 e 20.000:\n");

    for (int i = 2; i <= limite; i++)
    {
        if (numerosPrimos[i] == 1)
        {
            printf("%d\n", i);
        }
    }

    return 0;
}
