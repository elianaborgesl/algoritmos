/*2. Dado n, calcular a soma dos n primeiros n�meros naturais*/
#include <stdio.h>

int main()
{
    int num, soma = 0;

    printf("Por favor escreva um numero: ");
    scanf("%d", &num);


    if (num <= 0)
    {
        printf("Por favor, insira um numero positivo.\n");
    } else {
        for (int i = 1; i <= num; i++)
        {
            soma += i;
        }

        printf("A soma dos %d primeiros numeros naturais eh %d.\n", num, soma);
    }

    return 0;
}
