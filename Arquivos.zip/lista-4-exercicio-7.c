/*7. Dados n e uma sequ�ncia de n n�meros inteiros positivos, determinar a soma dos
n�meros pares, dos �mpares e as respectivas quantidades de cada um dos
subconjuntos.
*/
#include <stdio.h>

int main()
{
    int n, numero, somaPares = 0, somaImpares = 0, quantidadePares = 0, quantidadeImpares = 0;

    printf("Ola, digite a quantidade de numeros na sequencia: ");
    scanf("%d", &n);

    if (n <= 0)
    {
        printf("Por favor, insira um numero positivo para a quantidade de numeros.\n");
        return 1; // Saia do programa com c�digo de erro
    }

    for (int i = 0; i < n; i++)
    {
        printf("Digite o proximo numero: ");
        scanf("%d", &numero);

        if (numero % 2 == 0)
        {
            somaPares += numero;
            quantidadePares++;
        }
        else
        {
            somaImpares += numero;
            quantidadeImpares++;
        }
    }

    printf("Soma dos numeros pares: %d\n", somaPares);
    printf("Quantidade de numeros pares: %d\n", quantidadePares);
    printf("Soma dos numeros impares: %d\n", somaImpares);
    printf("Quantidade de numeros impares: %d\n", quantidadeImpares);

    return 0;
}
