/*9. Dado n e dois n�meros naturais i e j diferentes de 0, imprimir em ordem crescente os n
primeiros naturais que s�o m�ltiplos de i ou de j e ou de ambos. Exemplo: Para n = 6, i
= 2, j = 3 a sa�da dever� ser : 0, 2, 3, 4, 6, 8.*/
#include <stdio.h>

int main()
{
    int n, i, j;

    printf("Digite n: ");
    scanf("%d", &n);

    printf("Digite i: ");
    scanf("%d", &i);

    printf("Digite j: ");
    scanf("%d", &j);

    if (n <= 0 || i <= 0 || j <= 0)
    {
        printf("Por favor, insira n�meros naturais positivos para n, i e j.\n");
    }
        else
        {
        int numero = 0;
        int encontrados = 0;

        while (encontrados < n)
        {
            if (numero % i == 0 || numero % j == 0)
            {
                printf("%d ", numero);
                encontrados++;
            }
            numero++;
        }

        printf("\n");
    }

    return 0;
}
