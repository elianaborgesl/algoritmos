/*3. Dado n, imprimir os n primeiros naturais �mpares*/
#include <stdio.h>

int main() {
    int num;

    printf("Ola digite um numero : ");
    scanf("%d", &num);

    if (num <= 0)
    {
        printf("Por favor, insira um numero positivo.\n");
    }
        else
            {
            printf("Os primeiros %d numeros naturais impares sao:\n", num);
            for (int i = 1; num > 0; i += 2, num--)
                {
                printf("%d ", i);
                }
                printf("\n");
            }

    return 0;
}
