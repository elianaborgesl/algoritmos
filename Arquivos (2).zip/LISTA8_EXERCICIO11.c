
#include <stdio.h>

int main() {
    int A[10], B[10], C[20], i, j, tamanho = 0, existe;

    printf("Digite 10 numeros inteiros para o vetor A: ");
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &A[i]);
    }

    printf("Digite 10 numeros inteiros para o vetor B: ");
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &B[i]);
    }

    for (i = 0; i < 10; i++)
    {
        C[tamanho++] = A[i];
    }

    for (i = 0; i < 10; i++)
    {
        existe = 0;
        for (j = 0; j < tamanho; j++)
        {
            if (B[i] == C[j])
            {
                existe = 1;
                break;
            }
        }
        if (!existe)
        {
            C[tamanho++] = B[i];
        }
    }

    printf("Vetor uniao dos conjuntos A e B: ");
    for (i = 0; i < tamanho; i++)
    {
        printf("%d ", C[i]);
    }
    printf("\n");

    return 0;
}
