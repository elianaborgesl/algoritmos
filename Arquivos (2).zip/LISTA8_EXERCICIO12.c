
#include <stdio.h>

int main()
{
    int A[10], B[10], C[10], i, j, tamanho = 0;

    printf("Digite 10 numeros inteiros para o vetor A: ");
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &A[i]);
    }

    printf("Digite 10 numeros inteiros para o vetor B: ");
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &B[i]);
    }

    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 10; j++)
        {
            if (A[i] == B[j])
            {
                int existe = 0;
                for (int k = 0; k < tamanho; k++)
                {
                    if (C[k] == A[i])
                    {
                        existe = 1;
                        break;
                    }
                }
                if (!existe)
                {
                    C[tamanho++] = A[i];
                }
                break;
            }
        }
    }

    if (tamanho > 0)
    {
        printf("Valores da intersecao dos conjuntos A e B: ");
        for (i = 0; i < tamanho; i++)
        {
            printf("%d ", C[i]);
        }
        printf("\n");
    } else
    {
        printf("Nao ha valores em comum entre A e B\n");
    }

    return 0;
}
