#include <stdio.h>

int main()
{
    int numero, reverso = 0, digito;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    while (numero != 0)
    {
        digito = numero % 10;
        reverso = reverso * 10 + digito;
        numero = numero / 10;
    }

    printf("O reverso do numero e: %d\n", reverso);

    return 0;
}
