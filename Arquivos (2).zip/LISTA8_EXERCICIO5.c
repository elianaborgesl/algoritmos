#include <stdio.h>

int main()
{
    int numero, original, reverso = 0, digito;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    original = numero;

    while (numero != 0)
    {
        digito = numero % 10;
        reverso = reverso * 10 + digito;
        numero = numero / 10;
    }

    if (original == reverso)
    {
        printf("O numero e palindromo\n");
    } else
    {
        printf("O numero nao e palindromo\n");
    }

    return 0;
}
