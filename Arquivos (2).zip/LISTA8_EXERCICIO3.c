#include <stdio.h>

int main()
{
    int numero, posicao, contador = 0, digito;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    printf("Digite a posicao do digito desejado: ");
    scanf("%d", &posicao);

    if (numero < 0)
    {
        numero = -numero;
    }

    while (numero > 0)
    {
        digito = numero % 10;
        contador++;
        if (contador == posicao)
        {
            printf("O digito na posicao %d e: %d\n", posicao, digito);
            return 0;
        }
        numero = numero / 10;
    }

    printf("Posicao invalida\n");

    return 0;
}
