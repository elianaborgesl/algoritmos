#include <stdio.h>

int main()
{
    int A[10], x, encontrado = 0;

    printf("Digite 10 numeros inteiros: ");
    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &A[i]);
    }

    printf("Digite o valor a ser encontrado: ");
    scanf("%d", &x);

    for (int i = 0; i < 10; i++)
    {
        if (A[i] == x)
        {
            printf("Valor %d encontrado na posicao %d\n", x, i);
            encontrado = 1;
            break;
        }
    }

    if (!encontrado)
    {
        printf("Valor nao encontrado\n");
    }

    return 0;
}
