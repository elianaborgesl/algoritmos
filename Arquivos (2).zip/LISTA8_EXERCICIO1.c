#include <stdio.h>

int main()
{
    int x, y, mdc;


    printf("Digite dois numeros inteiros: ");
    scanf("%d %d", &x, &y);


    while (x != y)
    {
        if (x > y)
        {
            x = x - y;
        } else
        {
            y = y - x;
        }
    }

    mdc = x;


    printf("O MDC eh: %d\n", mdc);

    return 0;
}
