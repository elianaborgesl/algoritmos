#include <stdio.h>

int main()
{
    int n, x, y, temp;

    printf("Digite o tamanho do vetor: ");
    scanf("%d", &n);

    int A[n];

    printf("Digite os elementos do vetor: ");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &A[i]);
    }

    printf("Digite as posicoes x e y para trocar: ");
    scanf("%d %d", &x, &y);

    if (x >= 0 && x < n && y >= 0 && y < n)
    {
        temp = A[x];
        A[x] = A[y];
        A[y] = temp;

        printf("Vetor apos a troca: ");
        for (int i = 0; i < n; i++)
        {
            printf("%d ", A[i]);
        }
        printf("\n");
    } else
    {
        printf("Posicoes invalidas\n");
    }

    return 0;
}
