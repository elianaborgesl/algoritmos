#include <stdio.h>

int main()
{
    int n, contador = 0;


    printf("Digite um numero inteiro: ");
    scanf("%d", &n);


    if (n == 0)
    {
        contador = 1;
    } else
    {

        if (n < 0)
        {
            n = -n;
        }
        while (n > 0)
        {
            n = n / 10;
            contador++;
        }
    }
    printf("Quantidade de algarismos: %d\n", contador);

    return 0;
}
