#include <stdio.h>

int main()
{
    int A[10], contagem[10] = {0}, i, j;

    printf("Digite 10 numeros inteiros: ");
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &A[i]);
    }

    for (i = 0; i < 10; i++)
        {
        if (contagem[i] == -1)
        {
            continue;
        }
        int qtd = 1;
        for (j = i + 1; j < 10; j++)
        {
            if (A[i] == A[j])
            {
                qtd++;
                contagem[j] = -1;
            }
        }
        if (qtd > 1)
        {
            printf("Numero %d repetido %d vezes\n", A[i], qtd);
        }
    }

    return 0;
}
