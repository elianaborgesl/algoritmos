
#include <stdio.h>

int main()
{
    int A[10], i, j, temp;

    printf("Digite 10 numeros inteiros: ");
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &A[i]);
    }

    for (i = 0; i < 9; i++)
    {
        for (j = i + 1; j < 10; j++)
        {
            if (A[i] < A[j])
            {
                temp = A[i];
                A[i] = A[j];
                A[j] = temp;
            }
        }
    }

    printf("Vetor ordenado de forma decrescente: ");
    for (i = 0; i < 10; i++)
    {
        printf("%d ", A[i]);
    }
    printf("\n");

    return 0;
}
