#include <stdio.h>
//precisei usar fun�a�, que aprendi em algoritimos 2

#define N 5

int calcular_determinante(int matriz[N][N], int n)
{
    int det = 0, submatriz[N][N], i, j, k;

    if (n == 1)
    {
        return matriz[0][0];
    }

    if (n == 2)
    {
        return (matriz[0][0] * matriz[1][1]) - (matriz[0][1] * matriz[1][0]);
    }

    for (i = 0; i < n; i++)
    {
        int subi = 0;
        for (j = 1; j < n; j++)
        {
            int subj = 0;
            for (k = 0; k < n; k++)
            {
                if (k == i)
                {
                    continue;
                }
                submatriz[subi][subj] = matriz[j][k];
                subj++;
            }
            subi++;
        }
        det += (i % 2 == 0 ? 1 : -1) * matriz[0][i] * calcular_determinante(submatriz, n - 1);
    }
    return det;
}

int main()
{
    int M[N][N], i, j;

    printf("Digite os elementos da matriz 5x5: \n");
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            scanf("%d", &M[i][j]);
        }
    }

    int determinante = calcular_determinante(M, N);
    printf("O determinante da matriz e: %d\n", determinante);

    return 0;
}
