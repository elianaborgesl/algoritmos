/*4. Fa�a um algoritmo utilizando a Linguagem de Programa��o C que fa�a a soma dos n
primeiros n�meros primos naturais e apresente o resultado na tela.*/
#include <stdio.h>

int main()
{
    int n;
    printf("Digite o valor de n: ");
    scanf("%d", &n);

    int soma = 0;
    int contador = 0;
    int numero = 2;
    while (contador < n)
    {
        int ehPrimo = 1;

        if (numero <= 1)
        {
            ehPrimo = 0;
        }
        else
        {
            for (int i = 2; i * i <= numero; i++)
            {
                if (numero % i == 0)
                {
                    ehPrimo = 0;
                    break;
                }
            }
        }

        if (ehPrimo)
        {
            soma += numero;
            contador++;
        }

        numero++;
    }

    printf("A soma dos primeiros %d numeros primos naturais eh: %d\n", n, soma);

    return 0;
}
