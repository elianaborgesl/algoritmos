/*2. Fa�a um algoritmo utilizando a Linguagem de Programa��o C que permita ao usu�rio
informar a idade de quantas pessoas ele deseja registrar. Em seguida, o algoritmo deve
apresentar a soma das pessoas maiores de idade e a m�dia de idade das pessoas
menores de idade informadas.*/
#include <stdio.h>

int main()
{
    int quantidade, idade, somaMaioresIdade = 0, somaMenoresIdade = 0;
    int contadorMaioresIdade = 0, contadorMenoresIdade = 0;

    printf("Oiiii, Quantas pessoas vc deseja registrar? ");
    scanf("%d", &quantidade);

    if (quantidade <= 0)
    {
        printf("Por favor, insira um numero valido de pessoas.\n");
    }
        else
        {
            printf("Digite as idades das pessoas uma por uma:\n");

            for (int i = 1; i <= quantidade; i++)
            {
                printf("Idade da pessoa %d: ", i);
                scanf("%d", &idade);

                if (idade >= 18)
                {
                somaMaioresIdade += idade;
                contadorMaioresIdade++;
                }
                    else
                    {
                somaMenoresIdade += idade;
                contadorMenoresIdade++;
                    }
            }

        if (contadorMaioresIdade > 0)
        {
            printf("Soma das idades das pessoas maiores de idade: %d\n", somaMaioresIdade);
        }
        else
        {
            printf("Nenhuma pessoa maior de idade registrada.\n");
        }

        if (contadorMenoresIdade > 0)
        {
            float mediaMenoresIdade = (float)somaMenoresIdade / contadorMenoresIdade;
            printf("Media das idades das pessoas menores de idade: %.2f\n", mediaMenoresIdade);
        }
        else
        {
            printf("Nenhuma pessoa menor de idade registrada.\n");
        }
    }

    return 0;
}
