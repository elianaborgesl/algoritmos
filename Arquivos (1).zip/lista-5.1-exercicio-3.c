/*3. Fa�a um algoritmo utilizando a Linguagem de Programa��o C que permite ao usu�rio
transformar um n�mero natural em n�mero bin�rio e imprima o n�mero bin�rio na
tela.*/
#include <stdio.h>

int main()
{
    int numero;

    printf("Digite um numero decimal: ");
    scanf("%d", &numero);

    printf("Numero binario: ");

    if (numero == 0)
    {
        printf("0");
    }
    else
    {
        int binario[32]; // Armazena os d�gitos bin�rios
        int contador = 0;

        while (numero > 0)
        {
            binario[contador] = numero % 2;
            numero = numero / 2;
            contador++;
        }

        for (int i = contador - 1; i >= 0; i--)
        {
            printf("%d", binario[i]);
        }
    }

    printf("\n");

    return 0;
}
