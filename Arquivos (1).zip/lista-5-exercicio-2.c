/*2. Fa�a um programa em C que leia um valor inteiro e positivo n, e calcule a express�o
abaixo. Ap�s, imprima o resultado na tela.
Resultado = (1 + 1*2 + 1*3 + 1*4 + ... + 1*n)/n*/
#include <stdio.h>

int main()
{
    int n;
    float resultado = 0.0;

    printf("hello, Digite um valor inteiro e positivo n: ");
    scanf("%d", &n);

    if (n <= 0)
    {
        printf("Por favor, insira um valor inteiro e positivo.\n");
    }
    else
    {
        for (int i = 1; i <= n; i++)
        {
            resultado += 1.0 * i;
        }

        resultado = resultado / n;

        printf("O resultado eh: %.2f\n", resultado);
    }

    return 0;
}
