/*1. Fa�a um programa em C que leia um valor inteiro e positivo n, e calcule a express�o
abaixo. Ap�s, imprima o resultado na tela.
Soma = 1 + 1/2 + 1/3 + 1/4 + ... + 1/n*/
#include <stdio.h>

int main()
{
    int n;
    float soma = 0.0;

    printf("Digite um valor inteiro e positivo n: ");
    scanf("%d", &n);

    if (n <= 0)
    {
        printf("Por favor, insira um valor inteiro e positivo.\n");
    }
     else
     {
        for (int i = 1; i <= n; i++)
        {
            soma += 1.0 / i;
        }

        printf("A soma eh: %.2f\n", soma);
    }

    return 0;
}
