/*3. Fa�a um programa em C que leia cinco valores: a, b, c, d e e, todos n�meros inteiros, e
mostre-os em ordem crescente e decrescente.
*/
#include <stdio.h>

int main()
{
    int a, b, c, d, e;

    printf("Digite cinco numeros inteiros: ");
    scanf("%d %d %d %d %d", &a, &b, &c, &d, &e);

    int numeros[5] = {a, b, c, d, e};


    for (int i = 0; i < 5 - 1; i++)
    {
        for (int j = i + 1; j < 5; j++)
        {
            if (numeros[i] > numeros[j])
            {
                int temp = numeros[i];
                numeros[i] = numeros[j];
                numeros[j] = temp;
            }
        }
    }

    printf("Em ordem crescente: %d %d %d %d %d\n", numeros[0], numeros[1], numeros[2], numeros[3], numeros[4]);

    // decrescente
    for (int i = 0; i < 5 - 1; i++)
    {
        for (int j = i + 1; j < 5; j++)
        {
            if (numeros[i] < numeros[j])
            {
                int temp = numeros[i];
                numeros[i] = numeros[j];
                numeros[j] = temp;
            }
        }
    }

    printf("Em ordem decrescente: %d %d %d %d %d\n", numeros[0], numeros[1], numeros[2], numeros[3], numeros[4]);

    return 0;
}

