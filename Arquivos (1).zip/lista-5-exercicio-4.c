/*4. Fa�a um programa em C que receba 10 n�meros e indique quais s�o maiores que 25 e
menores que 85.*/
#include <stdio.h>

int main()
{
    int numeros[10];

    printf("Digite 10 numeros:\n");

    for (int i = 0; i < 10; i++)
    {
        printf("Numero %d: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    printf("Numeros maiores que 25 e menores que 85:\n");

    for (int i = 0; i < 10; i++)
    {
        if (numeros[i] > 25 && numeros[i] < 85)
        {
            printf("%d\n", numeros[i]);
        }
    }

    return 0;
}
