/*Fa�a um algoritmo utilizando a Linguagem de Programa��o C que leia a quantidade de
n�meros que o usu�rio desejar digitar e imprima a soma desses valores*/
#include <stdio.h>
int main()
{
    int i,n,numero,soma;
    printf("Ola, digite a quantidade de valor para fazermos a soma:\n");
    scanf("%d", &n);
        soma=0;

        for(i=1;i<n;i++)
        {
        printf("Digite o numero %d:\n", i);
        scanf("%d", &numero);

        soma= soma+numero;

        }
        printf("\n\n");
        printf("A soma eh igual a %d\n", soma);



    return 0;
}
